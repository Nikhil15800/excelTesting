package excelPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.excelUtility;

public class readingExcel extends TestBase {

	@BeforeClass
	public void setup() {
		initialization();
	}

	@Test(dataProvider = "loginData")
	public void loginTest(String user, String pwd, String exp) throws InterruptedException {
		Thread.sleep(5000);
		WebElement signin = driver.findElement(By.xpath("(//a[contains(text(),'Sign In')])[1]"));
		signin.click();
		WebElement email = driver.findElement(By.xpath("(//input[@id='email'])[1]"));
		email.sendKeys(user);
		WebElement password = driver.findElement(By.xpath("(//input[@id='pass'])[1]"));
		password.sendKeys(pwd);

		WebElement btn = driver.findElement(By.xpath("(//span[contains(text(),'Sign In')])[1]"));
		btn.click();

		String exp_title = "Home Page";
		String act_title = driver.getTitle();

		if (exp.equals("Valid")) {
			if (exp_title.equals(act_title)) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		}

		else if (exp.equals("inValid")) {
			if (exp_title.equals(act_title)) {
				Assert.assertTrue(false);
			} else {
				Assert.assertTrue(true);
			}
		}
	}

	@DataProvider(name = "loginData")
	public String[][] getData() throws IOException {
//		String loginData[][]= {
////				{"Nikhil001@gmail.com","Nikhil@123","inValid"},
////				{"Nikhil002@gmail.com","Nikhil@123","inValid"},
//				{"Nikhil004@gmail.com","Nikhil@123","Valid"},
////				{"Nikhil003@gmail.com","Nikhil@123","inValid"}
//				
//		};

		// Get data from excel :
		String path = ".\\excelFiles\\country.xlsx";
//		object of ExcelUtile file : 
		excelUtility excelUtility1 = new excelUtility(path);
//		File excelfile =  new File("./excelFiles/country.xlsx");
//        System.out.println(excelfile.exists());
//        FileInputStream fis = new FileInputStream(excelfile);
//        XSSFWorkbook workbook = new XSSFWorkbook(fis);
//        XSSFSheet sheet = workbook.getSheet("Sheet1");
//        int totalrows= sheet.getPhysicalNumberOfRows();
//        int totalcol= sheet.getRow(0).getLastCellNum();
//        
//        String [][] data = new String[totalrows-1][totalcol]; 
//        for(int i=0; i < totalrows-1;i++ ) 
//        {
//            for (int j=0; j < totalcol;j++) 
//            {
//                DataFormatter formatter = new DataFormatter(); 
//                data[i][j] =  formatter.formatCellValue(sheet.getRow(i+1).getCell(j));    
//            }  
//        }
//        
//        workbook.close();
//        fis.close();

//     return data;

		int totalrows = excelUtility1.getRowCount("Sheet1");
		int totalcols = excelUtility1.getCellCount("Sheet1", 1);

		String loginData[][] = new String[totalrows][totalcols];

		for (int i = 1; i <= totalrows; i++) {
			for (int j = 0; j < totalcols; j++) {
				loginData[i - 1][j] = excelUtility1.getCellData("Sheet1", i, j);
			}
		}
		return loginData;

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
