package Pages;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Base.TestBase;

public class test1 extends TestBase {

	private static Logger logger = LogManager.getLogger(test1.class);

	String mail[] = { "newuser0020@gmail.com" };
	int arrLength = mail.length;

	Select select;
	// Register
	@FindBy(xpath = "//div[@class='panel header']//a[normalize-space()='Create an Account']")
	WebElement createBtn;

	@FindBy(id = "firstname")
	WebElement fName;

	@FindBy(id = "lastname")
	WebElement lName;

	@FindBy(id = "email_address")
	WebElement Email;

	@FindBy(id = "password")
	WebElement password;

	@FindBy(id = "password-confirmation")
	WebElement Cpassword;

	@FindBy(xpath = "//button[@class='action submit primary']//descendant::span")
	WebElement createAccountBtn;

	@FindBy(xpath = "//div[@class='panel header']//button[@type='button']")
	WebElement welcomeDropdown;

	@FindBy(xpath = "//div[@aria-hidden='false']//a[normalize-space()='Sign Out']")
	WebElement signout;

	@FindBy(xpath = "//span[normalize-space()='Sale']")
	WebElement women;

	@FindBy(xpath = "(//span[normalize-space()=\"What's New\"])[1]")
	WebElement whatsNew;
//	
//	@FindBy()
//	WebElement expvalue;

	public test1() {
		PageFactory.initElements(driver, this);
	}

	public void FindChild() throws InterruptedException, IOException {

		Thread.sleep(5000);
		Actions actions = new Actions(driver);
		actions.contextClick(whatsNew).perform();

//		women.click();
	}

	public void registration() throws InterruptedException, IOException {
		logger.info("Registration Starts Here : ");

		for (int i = 0; i < arrLength; i++) {
			logger.info("Create account link");
			createBtn.click();

			logger.info("User name filed");
			fName.sendKeys(prop.getProperty("firstName"));
			lName.sendKeys(prop.getProperty("lastName"));

			logger.info("Email : " + mail[i]);
			Email.sendKeys(mail[i]);

			logger.info("Filled password : ");
			password.sendKeys(prop.getProperty("password"));
			Cpassword.sendKeys(prop.getProperty("password"));

			// ScreenShot
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			BufferedImage fullImage = ImageIO.read(scrFile);
			org.openqa.selenium.Point elementLocation = Cpassword.getLocation();
			int elementWidth = Cpassword.getSize().getWidth();
			int elementHeight = Cpassword.getSize().getHeight();
			BufferedImage elementScreenshot = fullImage.getSubimage(elementLocation.getX(), elementLocation.getY(),
					elementWidth, elementHeight);
			ImageIO.write(elementScreenshot, "png", scrFile);

			FileUtils.copyFile(scrFile, new File("D:\\Luma\\screenshot\\screenshot.png"));

			// End...Screenshot

			logger.info("Page scrolled : ");
//			JavascriptExecutor j = (JavascriptExecutor) driver;
//			j.executeScript("window.scrollBy(0,200)");
//
//			FileUtils.copyFile(scrFile, new File("D:\\Luma\\screenshot\\screenshot1.png"));

			logger.info("Button clicked : ");
			createAccountBtn.click();

			logger.info("Create an account Successfully : ");
			logger.info("Email : " + mail[i]);

			logger.info("SignOut : ");
			Thread.sleep(2000);
			welcomeDropdown.click();
			Thread.sleep(2000);
			signout.click();
		}
	}
}
