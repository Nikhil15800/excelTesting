package Pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import Base.TestBase;

public class sameId_SH extends TestBase {

	public void sameidsh() throws IOException {

		// For each loop:
		int arr[] = { 1, 2, 3, 4, 5, 6 };
		for (int i : arr) {
			WebElement sci = driver.findElement(By.xpath("(//li[@class='product-item'])[" + i + "]"));
			File src = sci.getScreenshotAs(OutputType.FILE);
			
			
			WebElement titleMultiple = driver.findElement(By.xpath("(//a[@class='product-item-link'])["+i+"]"));
			String text = titleMultiple.getText();
			System.out.println(text);
			
			
			File trg = new File(".\\scrshot\\"+text+".png");
			FileUtils.copyFile(src, trg);

		}

//		int i = 1;

		// With do while loop :

//		do
//		{
//			WebElement sci = driver.findElement(By.xpath("(//li[@class='product-item'])["+i+"]"));
//			File src = sci.getScreenshotAs(OutputType.FILE);
//			File trg = new File(".\\scrshot\\dowhile"+i+".png");
//			FileUtils.copyFile(src, trg);
//			i++;
//		}
//		while(i<=6);
		
		
		
		
		
		
		

		// With while loop : 
//		while(i<=6)
//		{
//			WebElement sci = driver.findElement(By.xpath("(//li[@class='product-item'])["+i+"]"));
//			File src = sci.getScreenshotAs(OutputType.FILE);
//			File trg = new File(".\\scrshot\\while"+i+".png");
//			FileUtils.copyFile(src, trg);
//			System.out.print("Number");
//			i++;
//		}	
		
		
		
		
		
		
		
		

		// With for loop :

//		for(int i1=1;i1<=6;i1++)
//		{
//		
//		WebElement sci = driver.findElement(By.xpath("(//li[@class='product-item'])["+i1+"]"));
//	    File src = sci.getScreenshotAs(OutputType.FILE);
//	    File trg = new File(".\\scrshot\\forloop"+i1+".png");
//	    FileUtils.copyFile(src, trg);
//		}
	}
}
