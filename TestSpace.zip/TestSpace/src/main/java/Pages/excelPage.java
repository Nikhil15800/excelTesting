package Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Base.TestBase;

public class excelPage extends TestBase{
	
	public static void main(String args[]) throws IOException
	{
		File file = new File("D:\\Luma\\codes.xlxs");
		FileInputStream inputStream = new FileInputStream(file);
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		
		HSSFSheet sheet = wb.getSheet("STUDENT_DATA");
		HSSFSheet sheet1 = wb.getSheetAt(1);
		
		
		 HSSFRow row1 = sheet.getRow(1);
		 sheet.getRow(1).getCell(1);
		 
	}
}

