package Pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.TestBase;

public class screeShot extends TestBase{
	
	@FindBy(xpath="(//li[@class='product-item'])[1]")
	WebElement screenshotadata1;
	
	@FindBy(xpath="(//li[@class='product-item'])[2]")
	WebElement screenshotadata2;
	
	@FindBy(xpath="(//li[@class='product-item'])[3]")
	WebElement screenshotadata3;
	
	@FindBy(xpath="(//li[@class='product-item'])[4]")
	WebElement screenshotadata4;
	
	@FindBy(xpath="(//li[@class='product-item'])[5]")
	WebElement screenshotadata5;
	
	
	
	public screeShot() {
		PageFactory.initElements(driver, this);
	}
	
	
	public void scroolPage() throws InterruptedException
	{
	
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("window.scrollBy(0,1800)");
		Thread.sleep(2000);
	}
	
	public void screenshotaPage() throws IOException
	{
		takenElementScreenshot(screenshotadata1,"screenshotadata1");
		takenElementScreenshot(screenshotadata2,"screenshotadata2");
		takenElementScreenshot(screenshotadata3,"screenshotadata3");
		takenElementScreenshot(screenshotadata4,"screenshotadata4");
		takenElementScreenshot(screenshotadata5,"screenshotadata5");
	}
	
	public static void takenElementScreenshot(WebElement element, String fileName)
	{
		File scrFile = element.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File("D:\\Luma\\screenshot\\"+fileName+".png"));
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

}
