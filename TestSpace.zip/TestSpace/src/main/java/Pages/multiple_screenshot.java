package Pages;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.TestBase;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class multiple_screenshot extends TestBase{

	@FindBy(xpath="//ul[@id='ui-id-2']//li//span[contains(text(),'Women')]")
	WebElement women;
	
	
	public multiple_screenshot() 
	{
		PageFactory.initElements(driver, this);
	}
	
	public void subchild() throws InterruptedException, IOException
	{
		
		for(int i=3;i<=8;i++) 
		{
			Thread.sleep(2000);
			System.out.println("Hello...");
			driver.findElement(By.xpath("//a[@id='ui-id-"+i+"']")).click();
			Thread.sleep(500);
			Screenshot src  = new  AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
			
			
			File SrcFile= new File(".\\scrshot\\nameField_"+i+".png");
			ImageIO.write(src.getImage(), "PNG", SrcFile);
		}
	}
}
