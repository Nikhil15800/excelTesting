package Pages;

import java.awt.AWTException;
import java.awt.Robot;

import Base.TestBase;

public class test2 extends TestBase{
	
	public void robotNewPage() throws AWTException
	{
		Robot robot = new Robot();
		robot.mouseMove(1000, 2000);
	}

}
