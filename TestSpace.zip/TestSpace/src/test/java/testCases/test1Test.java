package testCases;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.test1;

public class test1Test extends TestBase {

	test1 test;

	public test1Test() {
		super();
	}

	@BeforeClass
	public void setUp() {
		initialization();
		test = new test1();

	}

	@Test
	public void registrationTest() throws InterruptedException, IOException {
		test.registration();
	}

	@AfterClass
	public void teardown() {
		driver.quit();
	}
}
