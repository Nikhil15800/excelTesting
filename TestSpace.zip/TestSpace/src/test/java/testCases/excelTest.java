package testCases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.excelPage;

public class excelTest extends TestBase{
	excelPage excelPage;
	
	@BeforeClass
	public void setUp() {
		initialization();
		excelPage = new excelPage();

	}
	


}
