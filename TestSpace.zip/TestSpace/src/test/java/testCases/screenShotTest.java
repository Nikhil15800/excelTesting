package testCases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.screeShot;

public class screenShotTest extends TestBase
{
	screeShot screeShot1;
	
	@BeforeClass
	public void setUp() {
		initialization();
		screeShot1 = new screeShot();

	}
	
	@Test(priority = 1)
	public void scrollTest() throws InterruptedException
	{
		screeShot1.scroolPage();
	}
	
	@Test(priority = 2)
	public void screenTest() throws IOException
	{
		screeShot1.screenshotaPage();
	}
	
}
