package testCases;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.multiple_screenshot;

public class multiple_screenShotTest extends TestBase{
	multiple_screenshot multiple_screenshot1;
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		multiple_screenshot1 = new multiple_screenshot();
	}
	
	@Test
	public void subTest() throws InterruptedException, IOException
	{
		Thread.sleep(1000);
		multiple_screenshot1.subchild();
	}
	
	@AfterClass
	public void tearDown() {
		   driver.quit();
		}
}
