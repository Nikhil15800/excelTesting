package testCases;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.sameId_SH;

public class sameId_SH_Test extends TestBase{
	sameId_SH sameId_SH;
	
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		sameId_SH = new sameId_SH();
	}

	@Test
	public void sameidshTest() throws IOException
	{
		sameId_SH.sameidsh();
	}
	
	@AfterClass
	public void teardown()
	{
		driver.quit();
	}
}
