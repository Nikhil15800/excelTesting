package testCases;

import java.awt.AWTException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBase;
import Pages.test2;

public class test2Test extends TestBase{
	test2 testNew;
	
	@BeforeClass
	public void setup()
	{
		initialization();
		testNew = new test2();
	}
	
	@Test
	public void robotRunTest() throws AWTException
	{
		testNew.robotNewPage();
	}
}
